<?php
/**
 * Plugin Name: Code Highlighter with Copy Button
 * Plugin URI: https://ailynx.ru/plugins/code-highlighter-copy
 * Description: Professional code syntax highlighting with copy button functionality using Prism.js
 * Version: 1.0.0
 * Author: AI News Team
 * Author URI: https://ailynx.ru
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: code-highlighter-copy
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('CHC_VERSION', '1.0.0');
define('CHC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CHC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('CHC_PLUGIN_BASENAME', plugin_basename(__FILE__));
define('CHC_PLUGIN_FILE', __FILE__);

/**
 * Main plugin class
 */
class CodeHighlighterCopy {
    
    /**
     * Single instance of the class
     *
     * @var CodeHighlighterCopy
     */
    private static $instance = null;
    
    /**
     * Plugin components
     *
     * @var array
     */
    private $components = array();
    
    /**
     * Get singleton instance
     *
     * @return CodeHighlighterCopy
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    /**
     * Load required dependencies
     */
    private function load_dependencies() {
        // Load helper functions
        require_once CHC_PLUGIN_DIR . 'includes/functions.php';
        
        // Load core classes
        require_once CHC_PLUGIN_DIR . 'includes/class-assets.php';
        require_once CHC_PLUGIN_DIR . 'includes/class-shortcodes.php';
        
        // Load admin classes if in admin area
        if (is_admin()) {
            require_once CHC_PLUGIN_DIR . 'admin/class-admin.php';
        }
    }
    
    /**
     * Initialize WordPress hooks
     */
    private function init_hooks() {
        // Activation/Deactivation hooks
        register_activation_hook(CHC_PLUGIN_FILE, array($this, 'activate'));
        register_deactivation_hook(CHC_PLUGIN_FILE, array($this, 'deactivate'));
        
        // Initialize components
        add_action('init', array($this, 'init'));
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        
        // Add plugin action links
        add_filter('plugin_action_links_' . CHC_PLUGIN_BASENAME, array($this, 'add_action_links'));
    }
    
    /**
     * Initialize plugin components
     */
    public function init() {
        // Initialize assets manager
        $this->components['assets'] = new CHC_Assets();
        
        // Initialize shortcodes
        $this->components['shortcodes'] = new CHC_Shortcodes();
        
        // Initialize admin if in admin area
        if (is_admin()) {
            $this->components['admin'] = new CHC_Admin();
        }
        
        // Allow other plugins to hook into initialization
        do_action('chc_init', $this);
    }
    
    /**
     * Load plugin textdomain for translations
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            'code-highlighter-copy',
            false,
            dirname(CHC_PLUGIN_BASENAME) . '/languages'
        );
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Check PHP version
        if (version_compare(PHP_VERSION, '7.4', '<')) {
            deactivate_plugins(CHC_PLUGIN_BASENAME);
            wp_die(
                __('Code Highlighter with Copy Button requires PHP 7.4 or higher.', 'code-highlighter-copy'),
                __('Plugin Activation Error', 'code-highlighter-copy'),
                array('back_link' => true)
            );
        }
        
        // Check WordPress version
        if (version_compare(get_bloginfo('version'), '5.8', '<')) {
            deactivate_plugins(CHC_PLUGIN_BASENAME);
            wp_die(
                __('Code Highlighter with Copy Button requires WordPress 5.8 or higher.', 'code-highlighter-copy'),
                __('Plugin Activation Error', 'code-highlighter-copy'),
                array('back_link' => true)
            );
        }
        
        // Create default options
        $this->create_default_options();
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Log activation
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Code Highlighter with Copy Button activated');
        }
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clean up scheduled events if any
        wp_clear_scheduled_hook('chc_cleanup_cache');
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Log deactivation
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Code Highlighter with Copy Button deactivated');
        }
    }
    
    /**
     * Create default plugin options
     */
    private function create_default_options() {
        $default_options = array(
            'theme' => 'prism-tomorrow',
            'line_numbers' => true,
            'copy_button' => true,
            'copy_button_text' => __('Copy', 'code-highlighter-copy'),
            'copied_text' => __('Copied!', 'code-highlighter-copy'),
            'supported_languages' => array(
                'markup', 'css', 'javascript', 'php', 'python', 
                'sql', 'bash', 'json', 'yaml', 'markdown'
            ),
            'auto_detect_language' => false,
            'show_language_label' => true,
            'enable_on_frontend' => true,
            'enable_in_comments' => false,
            'cache_enabled' => true,
            'cache_expiration' => 86400, // 24 hours
        );
        
        // Add options with autoload
        foreach ($default_options as $key => $value) {
            add_option('chc_' . $key, $value, '', 'yes');
        }
        
        // Store plugin version
        add_option('chc_version', CHC_VERSION, '', 'yes');
    }
    
    /**
     * Add plugin action links
     *
     * @param array $links Existing links
     * @return array Modified links
     */
    public function add_action_links($links) {
        $settings_link = sprintf(
            '<a href="%s">%s</a>',
            esc_url(admin_url('options-general.php?page=code-highlighter-copy')),
            __('Settings', 'code-highlighter-copy')
        );
        
        array_unshift($links, $settings_link);
        
        return $links;
    }
    
    /**
     * Get plugin component
     *
     * @param string $component Component name
     * @return mixed|null Component instance or null
     */
    public function get_component($component) {
        return isset($this->components[$component]) ? $this->components[$component] : null;
    }
    
    /**
     * Check if plugin is compatible with current environment
     *
     * @return bool
     */
    public static function is_compatible() {
        return version_compare(PHP_VERSION, '7.4', '>=') 
            && version_compare(get_bloginfo('version'), '5.8', '>=');
    }
}

/**
 * Initialize the plugin
 *
 * @return CodeHighlighterCopy
 */
function chc_init() {
    return CodeHighlighterCopy::get_instance();
}

// Start the plugin
chc_init();